import React from 'react'

const DetailedRoom = () => {
  return (
    <div>DetailedRoom</div>
  )
}

export default DetailedRoom